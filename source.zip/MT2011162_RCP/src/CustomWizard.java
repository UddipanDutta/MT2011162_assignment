

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.ui.IWorkbench;

import utils.MySqlConnection;

//import com.mysql.jdbc.Connection;
//import com.mysql.jdbc.Statement;

public class CustomWizard extends Wizard {
	
	// Wizard pages
	private WizardPage _wizardPageNameInfo = null;
	private WizardPage _wizardPageAdressInfo = null;
	private WizardPage _wizardPageOpinionInfo = null;
	
	/**
	 * Constructor
	 */
	
	/*protected PageNameInfo _wizardPageNameInfo;
	protected PageAddressInfo _wizardPageAddressInfo;
	protected PageNameInfo _wizardPageInfo;
	*/
	public CustomWizard() {
		super();
		setNeedsProgressMonitor(true);
		
		// Create pages
		_wizardPageNameInfo = new PageNameInfo();
		_wizardPageAdressInfo = new PageAddressInfo();
		_wizardPageOpinionInfo = new PageOpinionInfo();
		
		setWindowTitle("Custom Wizard");
	}
	
	@Override
	public void addPages() {
		
		// Add pages
		addPage(_wizardPageNameInfo);
		addPage(_wizardPageAdressInfo);
		addPage(_wizardPageOpinionInfo);
	}
	
	@Override
	public boolean performFinish() {
		
		//((PageNameInfo)_wizardPageNameInfo).get_textFirstName();
		 
		//((PageAddressInfo)_wizardPageAdressInfo).get_textCountry();
		
		//((PageOpinionInfo)_wizardPageOpinionInfo).getTravelAgentName();
		
		// Process user input here
		
		Connection con=MySqlConnection.getConnection();
	//	Connection con = MySqlConnection.getConnection();
    	Statement st=null;
    	int rs=0;
    	
    	String query="Insert into tourinfo(tourName,source,destination,intermediate,agentName,doj) values('"+((PageNameInfo)_wizardPageNameInfo).get_textFirstName()+"','"+((PageAddressInfo)_wizardPageAdressInfo).get_textCountry()+"','"+((PageAddressInfo)_wizardPageAdressInfo).get_textCity()+"','"+((PageAddressInfo)_wizardPageAdressInfo).get_textStreet()+"','"+((PageOpinionInfo)_wizardPageOpinionInfo).getTravelAgentName()+"','"+((PageOpinionInfo)_wizardPageOpinionInfo).getDate()+"')";
    try {
    	st=con.createStatement();
		rs=st.executeUpdate(query);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 
    	return true;
		
	//	return true;
		
	}

	public void init(IWorkbench workbench, IStructuredSelection selection) {
		// TODO Auto-generated method stub
		
	}
}
