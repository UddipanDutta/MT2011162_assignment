package utils;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySqlConnection {
	
	static Connection Conn;
	
	public static Connection getConnection(){
		
		if(Conn ==null){
			
			try{
		    	Class.forName("com.mysql.jdbc.Driver");
			    Conn=DriverManager.getConnection(RunTimeSetting.url+RunTimeSetting.dbName,RunTimeSetting.dbUser,RunTimeSetting.dbPwd);		    	
			    if(Conn == null)
			    	System.out.println("error");
			    
			}
			catch (Exception e) {
			
				e.printStackTrace();
			}
			
			return Conn;
		}
		else{		
			return Conn;	
		}
		
		
		
	}

}
