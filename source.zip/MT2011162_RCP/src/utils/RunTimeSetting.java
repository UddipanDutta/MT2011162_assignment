package utils;

public class RunTimeSetting {
	
	 public static String dbUser="root"; 
	 public static String dbPwd="uddiz";
	 public static String dbName="travelplan";
	 public static String url="jdbc:mysql://localhost/";
	 
	 
}
