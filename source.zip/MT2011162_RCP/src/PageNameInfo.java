

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class PageNameInfo extends WizardPage {
	
	private Composite _parent = null;
	private Label _labelFirstName = null;
	private Label _labelLastName = null;
	private Text _textFirstName;
	
	/*public Text get_textFirstName() {
		return _textFirstName;
	}

	public void set_textFirstName(Text _textFirstName) {
		this._textFirstName = _textFirstName;
	}
*/
		public String get_textFirstName() {
		return _textFirstName.getText();
	}

	public void set_textFirstName(Text _textFirstName) {
		this._textFirstName = _textFirstName;
	}

	private Text _textLastName = null;

	/**
	 *  Constructor
	 */
	public PageNameInfo() {
		super("Create File - Name Info");
		setTitle("Create File - Name Info");
		setDescription("First page of the Wizard");
	}

	@Override
	public void createControl(Composite parent) {
		
		// Create parent container
		_parent = new Composite(parent, SWT.NONE);
		
		// Set layout to parent
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		_parent.setLayout(gridLayout);
		
		// Add widget
		_labelFirstName = new Label(_parent, SWT.NONE);
		_labelFirstName.setText("Enter Tour name:");
		
		// Add widget
		_textFirstName = new Text(_parent, SWT.BORDER);
		_textFirstName.setToolTipText("Enter Tour name");
		_textFirstName.addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
				
				if ( (_textFirstName.getText().isEmpty() == false)/* && (_textLastName.getText().isEmpty() == false) */) 
					setPageComplete(true);
				else
					setPageComplete(false);
			}
			
		});
		_textFirstName.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
		
		// Add widget
	//	_labelLastName = new Label(_parent, SWT.NONE);
	//	_labelLastName.setText("Enter last name:");
		
		// Add widget
/*		_textLastName = new Text(_parent, SWT.BORDER);
		_textLastName.setToolTipText("Enter last name");
		_textLastName.addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
				
				if ( (_textFirstName.getText().isEmpty() == false) && (_textLastName.getText().isEmpty() == false) ) 
					setPageComplete(true);
				else
					setPageComplete(false);
			}
			
		});
		_textLastName.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
	*/	
		// Set control
		setControl(_parent);
		
		// Set page status
		setPageComplete(false);
	}

	/*public String getTripName() {
	    return _textFirstName.getText();
	  }*/
}
