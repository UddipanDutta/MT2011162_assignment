

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;

public class PageAddressInfo extends WizardPage implements KeyListener {

	private Composite _parent = null;
	private Label _labelCountry = null;
	private Label _labelCity = null;
	private Label _labelStreet = null;
	private Label _labelEmail = null;
	private Text _textCountry;
	public String get_textCountry() {
		return _textCountry.getText();
	}

	public void set_textCountry(Text _textCountry) {
		this._textCountry = _textCountry;
	}

	public String get_textCity() {
		return _textCity.getText();
	}

	public void set_textCity(Text _textCity) {
		this._textCity = _textCity;
	}

	public String get_textStreet() {
		return _textStreet.getText();
	}

	public void set_textStreet(Text _textStreet) {
		this._textStreet = _textStreet;
	}

	private Text _textCity = null;
	private Text _textStreet = null;
	private Text _textEmail = null;
	private Button _buttonEnableEmail = null;
		
	/**
	 * Constructor
	 */
	public PageAddressInfo() {
		super("Create File - Address Info");
		setTitle("Create File - Address Info");
		setDescription("Second page of the Wizard");
	}

	@Override
	public void createControl(Composite parent) {
		
		// Create parent
		_parent = new Composite(parent, SWT.NONE);
		
		// Set layout to parent
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		_parent.setLayout(gridLayout);
		
		// Add widget
		_labelCountry = new Label(_parent, SWT.NONE);
		_labelCountry.setText("From");
		
		// Add widget
		_textCountry = new Text(_parent, SWT.BORDER);
		_textCountry.setToolTipText("From");
		_textCountry.addKeyListener(this);
		_textCountry.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
		
		// Add widget
		_labelCity = new Label(_parent, SWT.NONE);
		_labelCity.setText("To");
		
		// Add widget
		_textCity = new Text(_parent, SWT.BORDER);
		_textCity.setToolTipText("To");
		_textCity.addKeyListener(this);
		_textCity.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
		
		// Add widget
		_labelStreet = new Label(_parent, SWT.NONE);
		_labelStreet.setText("via");
		
		// Add widget
		_textStreet = new Text(_parent, SWT.BORDER);
		_textStreet.setToolTipText("via");
		_textStreet.addKeyListener(this);
		_textStreet.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
		
		// Add widget
	/*	_buttonEnableEmail = new Button(_parent, SWT.CHECK);
		_buttonEnableEmail.setText("Enable Email");
		GridData _gridData = new GridData();
		_gridData.horizontalSpan = 2;
		_buttonEnableEmail.setLayoutData(_gridData);
		_buttonEnableEmail.addListener(SWT.Selection, new Listener() {

			@Override
			public void handleEvent(Event event) {
							
				if ( ((Button)event.widget).getSelection() == true )
					_textEmail.setEnabled(true);
				else
					_textEmail.setEnabled(false);
			}
			
		});
		
		// Add widget
		_labelEmail = new Label(_parent, SWT.NONE);
		_labelEmail.setText("Email:");
		
		// Add widget
		_textEmail = new Text(_parent, SWT.BORDER);
		_textEmail.setToolTipText("Email");
		_textEmail.setEnabled(false);
		_textEmail.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
		*/
		// Set control
		setControl(_parent);
		
		// Set page status
		setPageComplete(false);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
		if (_textCountry.getText().isEmpty() == false &&
				_textCity.getText().isEmpty() == false &&
				_textStreet.getText().isEmpty() == false) {
			setPageComplete(true);
		} else {
			setPageComplete(false);
		}
		
	}

}
